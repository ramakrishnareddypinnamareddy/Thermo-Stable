// $Id: searchStatus.cpp 391 2005-06-12 12:44:57Z ninio $

#include "searchStatus.h"

searchStatus::searchStatus(const MDOUBLE startingTmp,const MDOUBLE factor ):
  _currentTmp(startingTmp),
  _factor(factor) {}


