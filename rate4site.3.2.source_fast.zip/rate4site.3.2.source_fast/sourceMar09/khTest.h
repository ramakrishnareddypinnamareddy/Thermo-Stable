// $Id: khTest.h 391 2005-06-12 12:44:57Z ninio $

#ifndef ___KH_TEST
#define ___KH_TEST

void makekhTest(const VVdouble & likelihoodVal, MDOUBLE diffNumOfFreeParam=0);


#endif

